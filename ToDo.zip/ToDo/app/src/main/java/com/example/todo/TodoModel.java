package com.example.todo;

public class TodoModel {
    int id;
    String title_mode,desc_model;

    public TodoModel(int id, String title_mode, String desc_model) {
        this.id = id;
        this.title_mode = title_mode;
        this.desc_model = desc_model;

    }
}
